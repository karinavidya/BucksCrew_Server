package com.example.banana.stocktest;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity implements WebRequestTask.WebRequestListener {

    TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv1 = (TextView) findViewById(R.id.tv1);

        WebRequestTask webRequest = new WebRequestTask(this,this);

        // SAMPLE GET REQUEST
        // - For GET requests, no parameters are usually required.
        //     webRequest.execute("http://192.168.253.1/get_all_account.php");
        // - For cases where parameters may be required, append it after the "?" sign.
        //     webRequest.execute("http://192.168.253.1/get_all_followers.php?userID=2");

        // SAMPLE POST REQUEST
        // - For parameters setup, please follow the examples below. Values may be varied, commented or uncommented.
        //   Please adjust usage to suit the testing needs.
        //     webRequest.addPostParm("userID", "11");
        //     webRequest.addPostParm("privateName", "testUser5");
        //     webRequest.addPostParm("publicName", "Test User7");
        //     webRequest.addPostParm("password", "1235");
        //     webRequest.addPostParm("accountEmailAddress", "testuser6@gmail.com");
        //     webRequest.addPostParm("text_test", "abc@gmail.com");
        // - Below are some samples to call the request. Use as needed.
        //     webRequest.execute("http://192.168.253.1/fn_create_account.php");
        //     webRequest.execute("http://192.168.253.1/fn_account_login.php");

        // TESTING PHP FILE
        // - For tests just in case the PHP files may be buggy, this file can serve as a scrap paper for testing.
        //     webRequest.execute("http://192.168.253.1/test_conn2.php");
        //     webRequest.execute("http://192.168.253.1/main_page.php");
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void webpageRequestFinish(String URL, WebRequestTask.WebRequestState state, String result)
    {

        if(state == WebRequestTask.WebRequestState.SUCCESS)
        {
            tv1.setText(result);
        }
        else
        {
            tv1.setText(result);
        }

    }
}
